#ifndef __DS_SENSOR_H
#define __DS_SENSOR_H

#include "main.h"

#if DS_SENSOR == 112
#include "bsp_mlx90614.h"
#define ds_init() mlx_init()
#define ds_update(x) mlx_getVal(x)
#endif

#if DS_SENSOR == 131
#include "ph_meter.h"
#define ds_init() ph_init()
#define ds_update(x) ph_read(x)
#endif

#if DS_SENSOR == 132
#include "ec_meter.h"
#define ds_init() ec_init()
#define ds_update(x) ec_read(x)
#endif

#endif