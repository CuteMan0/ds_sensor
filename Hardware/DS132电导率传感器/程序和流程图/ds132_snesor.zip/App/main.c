// working @ 24 MHz
#include "main.h"
//------------------------------STC lib--------------------------
#include "STC32G_Delay.h"
#if USB_INFO
#include "stc32_stc8_usb.h"
#endif
//------------------------------bsp lib------------------------------
#include "USB_CDC_drive.h"
#include "led_drive.h"
#include "key_drive.h"
//------------------------------  Task  ------------------------------
#include "ds_sensor.h"

float dat_for_printf;

void main(void)
{
    startup();

    DIS_LED_init();
    KEY_GPIO_init();

    // ��������ʼ��
    ds_init();

    while (1)
    {
        //���������ݸ���
        ds_update(&dat_for_printf);
        //��ӡ���ݣ�����USB_INFO��
#if USB_INFO
#if DS_SENSOR == 112
        printf("temp:%.2fC\n", dat_for_printf);
#elif DS_SENSOR == 131
        printf("ph:%.2f\n", dat_for_printf);
#elif DS_SENSOR == 132
        printf("ec:%.4fmS\n", dat_for_printf);
#endif
#endif
        delay_ms(100);
    }
}

void startup(void)
{
    WTST = 0;
    EAXFR = 1;
    CKCON = 0;

#if USB_INFO
    USB_CDC_Initialization();
    EA = 1;
    while (DeviceState != DEVSTATE_CONFIGURED)
        ;
    printf("USB Ready!\n");
#endif
}

#if USB_INFO
char putchar(char c)
{
    USB_SendData(&c, 1);
    return c;
}
#endif