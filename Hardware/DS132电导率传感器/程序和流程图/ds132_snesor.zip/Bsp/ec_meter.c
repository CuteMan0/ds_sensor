#include "ec_meter.h"

#include "stc32g.h"
#include "STC32G_ADC.h"
#include "STC32G_Delay.h"
#include "STC32G_EEPROM.h"
#include "STC32G_GPIO.h"

#include "key_drive.h"
#include "led_drive.h"

#define VIN 0.2f
#define V_REF 3.3f

sbit _C = P1 ^ 6;
sbit _B = P2 ^ 5;
sbit _A = P2 ^ 4;

#define SEL(x, y, z) \
    _C = (x);        \
    _B = (y);        \
    _A = (z)

#define REF_R0 SEL(0, 0, 0) // X0    0V
#define REF_R1 SEL(1, 1, 1) // X7  0.3V
#define REF_R2 SEL(1, 1, 0) // X6 0.87V
#define REF_R3 SEL(1, 0, 0) // X4  1.4V
#define REF_R4 SEL(1, 0, 1) // X5  1.8V
#define REF_R5 SEL(0, 1, 0) // X2  2.4V

static volatile float Q = 1.0f;   // 电导池常数
volatile float res_fb = 0.82f;    // 反馈电阻
volatile float offset_vol = 0.0f; // 减法器偏移量

u8 tmp_Q[2];
u8 flag_backup = 0;

static float Avg_Filter(float in_data);
static void Auto_Switcher(void);
static void Scan_Key(void);

void ec_init(void)
{
    ADC_InitTypeDef ADC_InitSruct;

    P1_MODE_IN_HIZ(GPIO_Pin_0|GPIO_Pin_1); // P1.0 P1.1设置为高阻输入(ADC0)
    P1_MODE_OUT_PP(GPIO_Pin_6); // P1.6设置为推挽输出(切换量程)
    P2_MODE_OUT_PP(GPIO_Pin_4); // P2.4设置为推挽输出(切换量程)
    P2_MODE_OUT_PP(GPIO_Pin_5); // P2.5设置为推挽输出(切换量程)

    REF_R0; // 设置基准为GND
    EEPROM_read_n(0, tmp_Q, sizeof(tmp_Q));
    if (0xff != tmp_Q[0] &&
        0xff != tmp_Q[1])
    {
        Q = (float)((u16)(tmp_Q[0] << 8) + tmp_Q[1]) / 1000;
    }

    ADC_InitSruct.ADC_SMPduty = 31;
    ADC_InitSruct.ADC_Speed = ADC_SPEED_2X16T;
    ADC_InitSruct.ADC_AdjResult = ADC_LEFT_JUSTIFIED;
    ADC_InitSruct.ADC_CsSetup = 0;
    ADC_InitSruct.ADC_CsHold = 1;

    ADC_Inilize(&ADC_InitSruct);
    ADC_PowerControl(ENABLE);
}

void ec_read(float *ec_val)
{
    u16 adc_val = 0;
    float adc_vol = 0.0f;
    *ec_val = 0.0f;

    Scan_Key();
    
    if (1 == flag_backup) // 开始EEPROM备份
    {
        flag_backup = 0;
#define K 12.84f // mS/cm
        adc_val = Get_ADCResult(ADC_CH1);//获取最初处理的信号电压
        adc_vol = (float)adc_val * V_REF / 4095; // raw voltage output
        Q = (K * res_fb * VIN / adc_vol); // new Q value
            
        tmp_Q[0] = (u16)(Q * 1000) >> 8;
        tmp_Q[1] = (u16)(Q * 1000);
        EEPROM_write_n(0, tmp_Q, sizeof(tmp_Q));
        DIS_LED_cal();
    }
        
    Auto_Switcher(); // 自动切换量程

    adc_val = Get_ADCResult(ADC_CH0); // 获得经过减法器和放大器后的电压值
    adc_vol = (float)adc_val * V_REF / 4095;
    adc_vol = adc_vol / 5.0f + offset_vol;
    adc_vol = Avg_Filter(adc_vol);          // 滤波
    *ec_val = adc_vol * Q / (res_fb * VIN); // k = Q/(R*|Vin|)*Vout
}

/************************************state machine************************************/
// states:
void Range_0(void); // 0-4
void Range_1(void); // 3.2-7.2
void Range_2(void); // 6.4-10.4
void Range_3(void); // 9.6-13.6
void Range_4(void); // 12.8-16.8
void Range_5(void); // 16.0-20.0

static eEvent eCurrentEvent = EVT_NO_EVENT;
static pfState pfCurrentState = Range_0;

// state transition table
StmRow_t stm[10] = {
    {Range_0, EVT_OverRange, Range_1},

    {Range_1, EVT_OverRange, Range_2},
    {Range_1, EVT_UnderRange, Range_0},

    {Range_2, EVT_OverRange, Range_3},
    {Range_2, EVT_UnderRange, Range_1},

    {Range_3, EVT_OverRange, Range_4},
    {Range_3, EVT_UnderRange, Range_2},

    {Range_4, EVT_OverRange, Range_5},
    {Range_4, EVT_UnderRange, Range_3},

    {Range_5, EVT_UnderRange, Range_4}};

static void Auto_Switcher(void)
{
    int idx = 0;
    int transitioned = 0;

    if (EVT_NO_EVENT != eCurrentEvent)
    {
        for (; idx < (int)(sizeof(stm) / sizeof(stm[0])); idx++)
        {
            if ((stm[idx].pSrcState == pfCurrentState) &&
                (stm[idx].eEvt == eCurrentEvent))
            {
                eCurrentEvent = EVT_NO_EVENT;
                pfCurrentState = stm[idx].pDestState;
                transitioned = 1;
                break;
            }
        }
    }

    if (NULL != pfCurrentState)
    {
        pfCurrentState();
    }
}

#define K2ADC(X) (u16)(res_fb * VIN * (X) / Q * 1240.9f)
void Range_0(void)
{
    u16 tmp;
    REF_R0;
    offset_vol = 0.0f;
    tmp = Get_ADCResult(ADC_CH1);

    if (tmp > K2ADC(4.0f))
    {
        eCurrentEvent = EVT_OverRange;
    }
}
void Range_1(void)
{
    u16 tmp;
    REF_R1;
    offset_vol = 0.296f;
    tmp = Get_ADCResult(ADC_CH1);

    if (tmp > K2ADC(7.2f))
    {
        eCurrentEvent = EVT_OverRange;
    }
    if (tmp < K2ADC(3.2f))
    {
        eCurrentEvent = EVT_UnderRange;
    }
}
void Range_2(void)
{
    u16 tmp;
    REF_R2;
    offset_vol = 0.874f;
    tmp = Get_ADCResult(ADC_CH1);

    if (tmp > K2ADC(10.4f))
    {
        eCurrentEvent = EVT_OverRange;
    }
    if (tmp < K2ADC(6.4f))
    {
        eCurrentEvent = EVT_UnderRange;
    }
}
void Range_3(void)
{
    u16 tmp;
    REF_R3;
    offset_vol = 1.395f;
    tmp = Get_ADCResult(ADC_CH1);

    if (tmp > K2ADC(13.6f))
    {
        eCurrentEvent = EVT_OverRange;
    }
    if (tmp < K2ADC(9.6f))
    {
        eCurrentEvent = EVT_UnderRange;
    }
}
void Range_4(void)
{
    u16 tmp;
    REF_R4;
    offset_vol = 1.804f;
    tmp = Get_ADCResult(ADC_CH1);

    if (tmp > K2ADC(16.8f))
    {
        eCurrentEvent = EVT_OverRange;
    }
    if (tmp < K2ADC(12.8f))
    {
        eCurrentEvent = EVT_UnderRange;
    }
}
void Range_5(void)
{
    u16 tmp;
    REF_R5;
    offset_vol = 2.387f;
    tmp = Get_ADCResult(ADC_CH1);

    if (tmp < K2ADC(16.0f))
    {
        eCurrentEvent = EVT_UnderRange;
    }
}

#define AVG_NUMS 10
volatile float ec_dat[AVG_NUMS] = {0.0f};
static float Avg_Filter(float in_data)
{
    float sum_data = 0.0f;
    int i = 0;
    // 前移（左移）滑动窗口
    for (; i < AVG_NUMS - 1; i++)
    {
        ec_dat[i] = ec_dat[i + 1];
        sum_data += ec_dat[i];
    }
    ec_dat[AVG_NUMS - 1] = in_data;
    sum_data += ec_dat[AVG_NUMS - 1];
    return (sum_data / AVG_NUMS);
}

void Scan_Key(void)
{
    if (0 == HOME_key)
    {
        delay_ms(20);
        if (0 == HOME_key)
        {
            while (0 == HOME_key)
                ;
            flag_backup = 1;
        }
    }
}
