#include "ph_meter.h"

#include "STC32G_ADC.h"
#include "STC32G_GPIO.h"

#define V_ADC 3.3f
#define V_REF 1.25f

#define K_1 -11.4856f // 酸斜率--delta PH /delta Vol
#define B_1 6.951f    // 截距
#define K_2 -12.0996f // 碱斜率--delta PH /delta Vol
#define B_2 6.956f    // 截距

#define OFFSET 0.00f

static float Avg_Filter(float in_data);

void ph_init(void)
{
    ADC_InitTypeDef ADC_InitSruct;

    P1_MODE_IN_HIZ(GPIO_Pin_0); // P1.0设置为高阻输入

    ADC_InitSruct.ADC_SMPduty = 31;
    ADC_InitSruct.ADC_Speed = ADC_SPEED_2X16T;
    ADC_InitSruct.ADC_AdjResult = ADC_LEFT_JUSTIFIED;
    ADC_InitSruct.ADC_CsSetup = 0;
    ADC_InitSruct.ADC_CsHold = 1;

    ADC_Inilize(&ADC_InitSruct);
    ADC_PowerControl(ENABLE);
}

void ph_read(float *ph_val)
{
    u16 adc_val = 0;
    float ph_vol = 0.0f;
    float tmp = 0.0f;

    adc_val = Get_ADCResult(ADC_CH0);
    ph_vol = (float)adc_val * V_ADC / 4096.0f - V_REF;

    // 电压信号转换至PH值 begin
    if (ph_vol > 0)
    {
        tmp = K_1 * (ph_vol - OFFSET) + B_1;
        tmp = Avg_Filter(tmp);
    }
    else
    {
        tmp = K_2 * (ph_vol - OFFSET) + B_2;
        tmp = Avg_Filter(tmp);
    }
    // 电压信号转换至PH值   end

    *ph_val = tmp < 0.0f ? 0.0f : (tmp > 14.0f ? 14.0f : tmp);
}

#define AVG_NUMS 20
volatile float ph_dat[AVG_NUMS] = {0.0f};
static float Avg_Filter(float in_data)
{
    float sum_data = 0.0f;
    int i = 0;
    // 前移（左移）滑动窗口
    for (; i < AVG_NUMS - 1; i++)
    {
        ph_dat[i] = ph_dat[i + 1];
        sum_data += ph_dat[i];
    }
    ph_dat[AVG_NUMS - 1] = in_data;
    sum_data += ph_dat[AVG_NUMS - 1];
    return (sum_data / AVG_NUMS);
}
