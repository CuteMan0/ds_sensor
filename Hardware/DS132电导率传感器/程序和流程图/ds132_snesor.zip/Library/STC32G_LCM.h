#ifndef	__STC32G_LCM_H
#define	__STC32G_LCM_H

#include	"config.h"

//========================================================================
//                              ��λ����
//========================================================================

sbit LCD_RS = P4^5;      //����/�����л�
sbit LCD_WR = P4^2;      //д����
sbit LCD_RD = P4^4;      //������
sbit LCD_CS = P7^7;      //Ƭѡ
sbit LCD_RESET = P7^3;   //��λ
sbit LCD_Backlight = P7^2;   //�����


//========================================================================
//                              ��������
//========================================================================

#define LCM_WRITE_CMD()					LCMIFCR = ((LCMIFCR & ~0x07) | 0x84)
#define LCM_WRITE_DAT()					LCMIFCR = ((LCMIFCR & ~0x07) | 0x85)
#define LCM_READ_CMD()					LCMIFCR = ((LCMIFCR & ~0x07) | 0x86)
#define LCM_READ_DAT()					LCMIFCR = ((LCMIFCR & ~0x07) | 0x87)

#define SET_LCM_DAT_LOW(n)			LCMIFDATL = (n)
#define SET_LCM_DAT_HIGH(n)			LCMIFDATH = (n)

//========================================================================
//                              ��������
//========================================================================

#define	MODE_I8080			0	//I8080ģʽ
#define	MODE_M6800			1	//M6800ģʽ

#define	BIT_WIDE_8			0	//8λ���ݿ���
#define	BIT_WIDE_16			2	//16λ���ݿ���

//========================================================================
//                              ��������
//========================================================================

typedef struct
{
	u8	LCM_Enable;					//LCM�ӿ�ʹ��  	ENABLE,DISABLE
	u8	LCM_Mode;						//LCM�ӿ�ģʽ  	MODE_I8080,MODE_M6800
	u8	LCM_Bit_Wide;				//LCM���ݿ���  	BIT_WIDE_8,BIT_WIDE_16
	u8	LCM_Setup_Time;			//LCMͨ�����ݽ���ʱ��  	0~7
	u8	LCM_Hold_Time;			//LCMͨ�����ݱ���ʱ��  	0~3
} LCM_InitTypeDef;


//========================================================================
//                              �ⲿ����
//========================================================================
extern bit LcmFlag;
extern u16 LCM_Cnt;

void LCM_Inilize(LCM_InitTypeDef *LCM);

#endif
